package jkyeiasare;

/*
/*
 * Class: CMSC203 
 * Instructor:Ahmed Tarek
 * Description: Calculate the holiday bonuses for companies
 * Due: 4/11/2023
 * Platform/compiler:Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Jeffrey Kyei-Asare
*/ 


import java.io.*;

import java.util.*;

import java.lang.*;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
class TwoDimRaggedArrayUtility{
	// definition of the method readFile
	// pass in a file and return a two dimensional ragged array of doubles
	public static double[][] readFile(File file) throws FileNotFoundException{
		
		int maxCol = 10; //set maxCol
		int maxRow = 10; //set maxRow
		
		String[][] tempArr = new String [maxRow][maxCol]; //create temp array
		
		for(int i = 0; i < maxRow; i++) { //for loop for rows
			for(int j = 0; i < maxCol; i++) { //for loops for col
				tempArr[i][j] = null; //set to null
			}
		}
		
		int x = 0;
		String line;
		try { //try to see if file is there
			Scanner sc = new Scanner(file); //scanner for file
			while(sc.hasNextLine()) { //while file is not empty
				line = sc.nextLine();
				if(line != null) { //check if row is valid
					tempArr[x] = line.split(" "); //set temp array to elements in file and seperate by space
					x++; //increase x
				}
				
			}
			sc.close(); //close scanner
		}catch (FileNotFoundException e) {
			System.out.print("No file found");
			return null;
		}
		
		double[][] newArr = new double [x][]; //new array based on number of rows
		
		int start = 0;
		do {
			int numOfCol = tempArr[start].length;
			newArr[start] = new double[numOfCol];
			start++;
		}while(start < x);
		
		for(int row = 0; row < x; row++) {
			for(int col = 0; col < newArr[row].length; col++) {
				newArr[row][col] = Double.valueOf(tempArr[row][col]);
				System.out.print(newArr[row][col] + " ");
			}
			System.out.println();
		}
		return newArr;	
		}

// definition of the method writeToFile
// pass in a two dimensional ragged array of doubles and a file,
// and writes the ragged array into the file. Each row is on a
// separate line and each double is separated by a space.

	
	public static void writeToFile(double[][] data, File outputFile) throws FileNotFoundException {
		PrintWriter pWriter = new PrintWriter(outputFile); //create printWriter
		for(int j = 0; j < data.length; j++) { //for loop for row
			for(int k = 0; k < data[j].length; k++) { //for loop for col
				pWriter.print(data[j][k]);
				pWriter.print(" ");
			}
			pWriter.print("\n"); //print
		}
		pWriter.close(); //close
	}
	
// definition of the method getTotal
// pass in a two dimensional ragged array of doubles
// and returns the total of the elements in the array.

	public static double getTotal(double[][] raggedArr)
	{
		double total = 0;
	// find the sum of the values of the 2D array
		for (int i = 0; i < raggedArr.length; i++)
		{
			for (int j = 0; j < raggedArr[i].length; j++)
			{
				total += raggedArr[i][j];
			}
		}
		return total;
	}

// definition of the method getAverage

// pass in a two dimensional ragged array of doubles

// and returns the average of the elements in the array

	public static double getAverage(double[][] raggedArr)
	{
		double total = 0;
		double numOfElements = 0;
		// find the sum of the values of the 2D array
		for (int i = 0; i < raggedArr.length; i++)
		{
			for (int j = 0; j < raggedArr[i].length; j++)
			{
				total += raggedArr[i][j];
				numOfElements += 1;
			}
		}
		// find and return the average
		return (total / numOfElements);
		
	}

// definition of the method getRowTotal
// pass in a two dimensional ragged array of doubles and a row index
// and returns the total of that row. Row index 0 is the first row in the
// array.

	public static double getRowTotal(double[][] raggedArr, int rowIndex)
	{
		double total = 0;
		for (int j = 0; j <raggedArr[rowIndex].length; j++)
		{
			total += raggedArr[rowIndex][j];
		}
		return total;
	}

// definition of the method getColumnTotal
// pass in a two dimensional ragged array of doubles
// and a column index and returns the total of that column.

	public static double getColumnTotal(double[][] raggedArr, int colIndex)
	{
		double total = 0;
		for (int i = 0; i < raggedArr.length; i++)
		{
			if (colIndex <= raggedArr[i].length - 1) {
				total += raggedArr[i][colIndex];
			}
		}
		return total;
	}

// definition of the method getHighestInRow
// pass in a two dimensional ragged array of doubles and a
// row index and returns the largest element in that row.

	public static double getHighestInRow(double[][] raggedArr, int rowIndex)
	{
		double highest = raggedArr[rowIndex][0];
		for (int j = 1; j < raggedArr[rowIndex].length; j++)
		{
			if (raggedArr[rowIndex][j] > highest)
				highest = raggedArr[rowIndex][j];
			}
		return highest;
	}

// 8 definition of the method getHighestInRowIndex
// takes a two dimensional ragged array of doubles and a
// row index and returns the index of the largest element in that row

	public static int getHighestInRowIndex(double[][] raggedArr, int row)
	{
		int index = 0;
		for (int i = 0; i < raggedArr[row].length; ++i)
		{
			if (raggedArr[row][i] > raggedArr[row][index])
			{
				index = i;
			}
		}
		return index;
	}

// definition of the method getLowestInRow
// takes a two dimensional ragged array of doubles and a
// row index and returns the smallest element in that row.

	public static double getLowestInRow(double[][] raggedArr, int rowIndex)
	{
		double lowest = raggedArr[rowIndex][0];
		for (int j = 1; j < raggedArr[rowIndex].length; j++)
		{
			if (raggedArr[rowIndex][j] < lowest)
				lowest = raggedArr[rowIndex][j];
		}
		return lowest;
	}

// 10 definition of the method getLowestInRowIndex
// takes a two dimensional ragged array of doubles and a
// row index and returns the index of the smallest element in that row.

	public static int getLowestInRowIndex(double[][] raggedArr, int row)
	{
		int index = 0;
		for (int i = 1; i < raggedArr[row].length; ++i)
		{
			if (raggedArr[row][i] < raggedArr[row][index])
			{
				index = i;
			}
	}
		return index;
	}

// definition of the method getHighestInColumn
// pass in a two dimensional ragged array of doubles
// and a column index and returns the largest element in that column
	public static double getHighestInColumn(double[][] raggedArr, int colIndex)
	{
		double highest = raggedArr[0][colIndex];
		for (int i = 1; i < raggedArr.length; i++)
		{
			if (colIndex <= raggedArr[i].length - 1)
			{
				if (raggedArr[i][colIndex] > highest) {
					highest = raggedArr[i][colIndex];
				}
			}
	}
	return highest;
	}

// 12 definition of the method getHighestInColumnIndex
// takes a two dimensional ragged array of doubles and a
// row index and returns the index of the largest element in that column.

	public static int getHighestInColumnIndex(double[][] raggedArr, int col_index)
	{
		int highest_ind = 0;
		for (int i = 0; i < raggedArr.length; i++)
		{
			if (raggedArr[i].length > col_index)
			{
				if (raggedArr[i][col_index] > raggedArr[highest_ind][col_index]) {
					highest_ind = i;
				}
			}
		}
	return highest_ind;
	}

// definition of the method getLowestInColumn
// pass in a two dimensional ragged array of doubles and a column
// index and returns the smallest element in that column

	public static double getLowestInColumn(double[][] raggedArr, int colIndex)
	{
	double lowest = raggedArr[0][colIndex];
		for (int i = 0; i < raggedArr.length; i++)
		{
			if (colIndex <= raggedArr[i].length - 1) {
				if (raggedArr[i][colIndex] < lowest) {
					lowest = raggedArr[i][colIndex];
				}
			}
		}
	return lowest;
	}

// 14 definition of the method getLowestInColumnIndex
// takes a two dimensional ragged array of doubles and a
// row index and returns the index of the lowest element in that column.
	public static int getLowestInColumnIndex(double[][] raggedArr, int col_index)
	{
		int highest_ind = 0;
		for (int i = 0; i < raggedArr.length; i++)
		{
			if (raggedArr[i].length > col_index)
			{
				if (raggedArr[i][col_index] < raggedArr[highest_ind][col_index])
					highest_ind = i;
			}
		}
		return highest_ind;
	}

// definition of the method getHighestInArray
// pass in a two dimensional ragged array of doubles
// and returns the largest element in the array.
	public static double getHighestInArray(double[][] raggedArr)
	{
		double highest = raggedArr[0][0];
		for (int i = 0; i < raggedArr.length; i++)
		{
			for (int j = 0; j < raggedArr[i].length; j++)
			{
				if (raggedArr[i][j] > highest)
					highest = raggedArr[i][j];
			}
		}
		return highest;
	}

// definition of the method getLowestInArray
// pass in a two dimensional ragged array of doubles
// and returns the smallest element in the array.
	public static double getLowestInArray(double[][] raggedArr)
	{
		double lowest = raggedArr[0][0];
		for (int i = 0; i < raggedArr.length; i++)
		{
			for (int j = 0; j < raggedArr[i].length; j++)
			{
				if (raggedArr[i][j] < lowest) {
					lowest = raggedArr[i][j];
				}
		}
		}
		return lowest;
	}
}