package jkyeiasare;

/*
 * Class: CMSC203 
 * Instructor:Ahmed Tarek
 * Description: Calculate the holiday bonuses for companies
 * Due: 4/11/2023
 * Platform/compiler:Eclipse
 * I pledge that I have completed the programming 
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Jeffrey Kyei-Asare
*/

public class HolidayBonus {

	//Holiday bonus
	public static double[] calculateHolidayBonus(double[][] data, double high, double low, double other) {
	
		double[] holidayBonusArr = new double[data.length]; //1-d array array of length double
		for(int i = 0; i < data.length; i++) { //for loop for row
			for(int k = 0; k<data[i].length; k++) { //for loop for col
				if (data[i][k] == TwoDimRaggedArrayUtility.getHighestInColumn(data, k)) { //if highest
					holidayBonusArr[i] += high; //add high
				}
				else if(data[i][k] == TwoDimRaggedArrayUtility.getLowestInColumn(data, k) ) { //if lowest
					holidayBonusArr[i]+= low; //add low
				}
				else {
					holidayBonusArr[i] += other; //add other
				}
			}
		}
		return holidayBonusArr; //return array
		
	}

	//totalHolidayBonus
	public static double calculateTotalHolidayBonus(double[][] data, double high, double low, double other) {
		double total=0; //total
		double[] holidayBonusArr = new double[data.length]; //1-d array for bonus
		for (int i=0; i<data.length; i++) { //for loop for row
		
			for (int k=0; k<data[i].length; k++) { //for loop for col
			
				if (data[i][k] == TwoDimRaggedArrayUtility.getHighestInColumn(data, k)) { //if highest
				
					holidayBonusArr[i] += high; //add high
				}
				
				else if(data[i][k] == TwoDimRaggedArrayUtility.getLowestInColumn(data, k) ) { //if lowest
				
					holidayBonusArr[i]+= low; //add low
				}
				
				else {
				
					holidayBonusArr[i] += other; //add other
				}
			
			}
			
			
			}
		
		for(int i =0;i<holidayBonusArr.length;i++) { //for loop for bonus arr
		
			total += holidayBonusArr[i]; //add to total
		}
		
		
		return total; //return total
		
	}
}