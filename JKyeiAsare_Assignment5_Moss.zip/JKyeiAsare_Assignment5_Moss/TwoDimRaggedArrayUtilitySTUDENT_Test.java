package jkyeiasare;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


//import static org.junit.jupiter.api.Assertions.*;
//
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//
//import static org.junit.Assert.*;
//
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
//
import org.junit.After;
import org.junit.Before;

public class TwoDimRaggedArrayUtilitySTUDENT_Test {
	//STUDENT fill in dataSetSTUDENT with values, it must be a ragged array
	private double[][] dataSetSTUDENT = { {10, 20, 30 ,40},
            {50, 60, 70, 80, 90, 100} };
	
	private File inputFile,outputFile;

	@Before
	public void setUp() throws Exception {
		outputFile = new File("TestOut.txt");
	}

	@After
	public void tearDown() throws Exception {
		dataSetSTUDENT = null;
		inputFile = outputFile = null;
	}

	/**
	 * Student Test getTotal method
	 * Return the total of all the elements in the two dimensional array
	 */
	@Test
	public void testGetTotal() {
		double student = TwoDimRaggedArrayUtility.getTotal(dataSetSTUDENT);
		try {
			assertEquals(550.0, student);
		}
		catch (Exception e) {
			
		}
	}

	/**
	 * Student Test getAverage method
	 * Return the average of all the elements in the two dimensional array
	 */
	@Test
	public void testGetAverage() {
		double student = TwoDimRaggedArrayUtility.getAverage(dataSetSTUDENT);
		try {
			assertEquals(55.0, student);
		}
		catch (Exception e) {
			
		}
	}

	/**
	 * Student Test getRowTotal method
	 * Return the total of all the elements of the row.
	 * Row 0 refers to the first row in the two dimensional array
	 */
	@Test
	public void testGetRowTotal() {
		double student = TwoDimRaggedArrayUtility.getRowTotal(dataSetSTUDENT, 0);
		try {
			assertEquals(100.0, student);
		}
		catch (Exception e) {
			
		}	
	}


	/**
	 * Student Test getColumnTotal method
	 * Return the total of all the elements in the column. If a row in the two dimensional array
	 * doesn't have this column index, it is not an error, it doesn't participate in this method.
	 * Column 0 refers to the first column in the two dimensional array
	 */
	@Test
	public void testGetColumnTotal() {
		double student = TwoDimRaggedArrayUtility.getColumnTotal(dataSetSTUDENT, 0);
		try {
			assertEquals(60.0, student);
		}
		catch (Exception e) {
			
		}
	}


	/**
	 * Student Test getHighestInArray method
	 * Return the largest of all the elements in the two dimensional array.
	 */
	@Test
	public void testGetHighestInArray() {
		double student = TwoDimRaggedArrayUtility.getHighestInArray(dataSetSTUDENT);
		try {
			assertEquals(100.0, student);
		}
		catch (Exception e) {
			
		}
	}
	

	/**
	 * Test the writeToFile method
	 * write the array to the outputFile File
	 * then read it back to make sure formatted correctly to read
	 * 
	 */
	@Test
	public void testWriteToFile() {
		//TwoDimRaggedArrayUtility.writeToFile(dataSetSTUDENT, outputFile);
		
		//while(outputFile.readLine() != null)
		//try {
			//assertEquals(100.0, student);
		//}
		//catch (Exception e) {
			
		//}	
	}

}
